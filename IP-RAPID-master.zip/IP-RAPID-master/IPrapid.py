#cut here or dare to see code#
#----------------------------------------------------------------------------------------------------------------------------#
import sys;
import stem.socket;
import time;
from stem.control import Controller;
import sys;
import getpass;
import stem.connection;
import stem.socket;
from stem.connection import connect;
import stem.process;
from stem import Signal
from stem.process import launch_tor;
controller = connect();
print("please type in your tor control port");
Cport = int(input());
cSock = stem.socket.ControlPort(port = Cport);
stem.connection.authenticate(cSock);
ips = 0;
x = 1;
print("if you have a password to authenticate with tor put it here please and thankyou");
passwd = input();
with Controller.from_port(port = Cport) as controller:
    controller.authenticate(passwd); #auth
    while(x > 0):
        time.sleep(10);
        print("number of ip changes",ips); #text to tell you how many ips have been changed
        ips = ips + 1;
        controller.signal(Signal.NEWNYM); #ip change
        controller.clear_cache();
#----------------------------------------------------------------------------------------------------#
        #wow your not a scriptkiddie and actually know code or just are curoius as heck#